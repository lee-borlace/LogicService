# And now, a word from our sponsor...
Hello all!  

After a rather lengthy hiatus, I've returned to focus some attention on this project.  Much of the project-related delay involved reworking the logic for bagof and adding support for eval.  (I won't bore you with the non-project-related reasons...)  I hope the new implementation is closer to that of other Prolog implementations such as GNU Prolog.

My next focus will be on addressing suggestions and issues I've received, and enhancements to allow Prolog.NET to be more easily integrated with other .NET applications.

Thank you again for your interest and patience!

# Project Description
A .NET-base implementation of Prolog based on the Warren Abstract Machine (WAM) architecture.

This project contains:
* Prolog - the primary assembly containing the Prolog.NET compiler and interpreter.
* PrologLibrary - an assembly containing external functions callable by Prolog.NET programs.
* PrologSchedule - a WPF application demonstrating the use of Prolog.NET from a client C# application.
* PrologTest - a console application used for testing.
* PrologWorkbench - a WPF application used for editing, running and debugging Prolog.NET programs.

## Notes
* Please see [Documentation](Documentation) page for additional information about Prolog.NET.
* The project source code currently contains TFS source control bindings.  These bindings should be removed if you have not installed the Visual Studio Team Explorer.

## Project Status
This project is under active development.

## Additional References
For additional information about the Warren Abstract Machine, the following resources are recommended:
* [Warren abstract machine (Wikipedia)](http://en.wikipedia.org/wiki/Warren_abstract_machine)
* [An abstract Prolog instruction set](http://www.ai.sri.com/pubs/files/641.pdf)
* [Warren's Abstract Machine: A Tutorial Reconstruction](http://web.archive.org/web/20030213072337/http://www.vanx.org/archive/wam/wam.html)