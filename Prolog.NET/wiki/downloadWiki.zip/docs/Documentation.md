# Introduction
Prolog.NET is a .NET-based Prolog interpreter based on the Warren Abstract Machine (WAM) architecture.

The original paper describing what would become known as the Warren Abstract Machine was published by David H. D. Warren in 1983.  A book clarifying and expanding on the details in this paper was published by Hassan Aït-Kaci in 1991.

Prolog.NET deviates from the standard WAM architecture in a few important respects.  Most significantly, it relies on the garbage collection support provided by the CLI.  No explicit memory management is performed by Prolog.NET.  All variables, environments and choice points reside in the CLI heap. .  To ensure objects in the heap can be reclaimed in a timely fashion, Prolog.NET must still respect the context of variables when binding variables to other variables and properly “unwind” variable bindings during backtracking.

In the original WAM architecture, the terms “variable” and “value” in opcode names refer to unbound and bound variables, respectively.  Prolog.NET uses the terms “unbound variable” and “bound variable”.  Further, the WAM architecture uses the term “constant” to refer to integers, strings and other extra-logical objects.   Prolog.NET reserves instead the term “value” for this use since these entities can also be created dynamically by external library functions.

Prolog.NET can be called directly from client applications.  A WPF-based IDE is also supplied.

For more information, please see the [Prolog.NET Reference Guide](Documentation_Prolog.NET.pdf).
