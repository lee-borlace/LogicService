﻿/* Copyright © 2010 Richard G. Todd.
 * Licensed under the terms of the Microsoft Public License (Ms-PL).
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prolog
{
    internal enum WamDeferenceTypes
    {
        None,
        BoundVariables,
        AllVariables
    }
}
