﻿/* Copyright © 2010 Richard G. Todd.
 * Licensed under the terms of the Microsoft Public License (Ms-PL).
 */

using Prolog.Code;

namespace Prolog
{
    internal delegate bool PredicateDelegate(WamMachine machine, WamReferenceTarget[] arguments);
}
