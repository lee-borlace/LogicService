﻿/* Copyright © 2010 Richard G. Todd.
 * Licensed under the terms of the Microsoft Public License (Ms-PL).
 */

using System;

namespace Prolog
{
    internal static class TermProcessingMethods
    {
        public static bool Functor(WamMachine machine, WamReferenceTarget[] arguments)
        {
            throw new NotImplementedException();
        }

        public static bool Arg(WamMachine machine, WamReferenceTarget[] arguments)
        {
            throw new NotImplementedException();
        }

        public static bool ComposedOf(WamMachine machine, WamReferenceTarget[] arguments)
        {
            throw new NotImplementedException();
        }

        public static bool CopyTerm(WamMachine machine, WamReferenceTarget[] arguments)
        {
            throw new NotImplementedException();
        }
    }
}
