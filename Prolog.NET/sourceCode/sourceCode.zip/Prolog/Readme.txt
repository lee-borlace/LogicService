See Copyright.txt for copyright information.

See License.txt for licensing information.
