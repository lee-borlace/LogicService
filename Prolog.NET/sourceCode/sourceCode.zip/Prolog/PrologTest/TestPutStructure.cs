﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Prolog;

namespace PrologTest
{
    public sealed class TestPutStructure
    {
        public void Test1()
        {
            //WamMachine wam = new WamMachine(100);

            //wam.Environment = new WamEnvironment(null, 2);

            //// a(X1,X1)
            ////
            //Functor functor = new Functor("a", 2);
            //wam.PutStructure(functor, WamVariable.Temporary(0));
            //wam.SetVariable(WamVariable.Temporary(1));
            //wam.SetValue(WamVariable.Temporary(1));
        }
    }
}
